@extends('layouts.app')

@section('content')
<div class="col-lg-8 col-md-10">
    <h2 class="text-center">
        Category :
        <span class="highlight">{{ $category->name }}</span>
    </h2>
    <div class="blog-loop">
        @forelse ($posts as $post)
        <div class="post-box mb-40">
            <div class="post-media">
                <img src="{{ assetFile($post->image) }}" alt="Image">
            </div>
            <div class="post-desc">
                <a href="{{ route('category.posts',$post->category->slug) }}" class="cat">{{ $post->category->name }}</a>
                <h2>
                    <a href="{{ route('post.details',$post->slug) }}">{{ $post->title }}</a>
                </h2>
                <ul class="post-meta">
                    <li><a href="{{ route('post.details',$post->slug) }}"><i class="far fa-eye"></i>{{ $post->visitors->count() }} Views</a></li>
                    <li><a href="{{ route('post.details',$post->slug) }}"><i class="far fa-comments"></i>{{ $post->comments_count }} Comments</a></li>
                    <li><a href="{{ route('post.details',$post->slug) }}"><i class="far fa-calendar-alt"></i>{{ $post->created_at->format('dS M Y') }}</a></li>
                </ul>
                <p>{{ Str::words(strip_tags($post->description),15) }}</p>

                <div class="post-footer">
                    <div class="author">
                        <a href="{{ route('post.details',$post->slug) }}">
                            <img src="{{ assetFile($post->user->image) }}" alt="Image" height="50">
                            by {{ $post->user->name }}
                        </a>
                    </div>
                    <div class="read-more">
                        <a href="{{ route('post.details',$post->slug) }}"><i class="far fa-arrow-right"></i>Read More</a>
                    </div>
                </div>
            </div>
        </div>
        @empty
        <h3 class="text-center">No Posts Found!</h3>
        @endforelse

    </div>
    <div class="pagination-wrap">
        {{ $posts->links('pagination::theme-paginate') }}
    </div>
</div>
@endsection


