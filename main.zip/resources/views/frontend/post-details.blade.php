@extends('layouts.app')
@section('title')
  {{ $post->title }} -
@endsection
@section('meta')
    <!-- Schema.org markup for Google+ -->
    <meta itemprop="name" content="{{ $post->meta_title }}">
    <meta itemprop="description" content="{{ $post->meta_description }}">
    <meta itemprop="image" content="{{ assetFile($post->meta_image) }}">

    <!-- Twitter Card data -->
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="@publisher_handle">
    <meta name="twitter:title" content="{{ $post->meta_title }}">
    <meta name="twitter:description" content="{{ $post->meta_description }}">
    <meta name="twitter:creator" content="@author_handle">
    <meta name="twitter:image" content="{{ assetFile($post->meta_image) }}">

    <!-- Open Graph data -->
    <meta property="og:title" content="{{ $post->meta_title }}" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="{{ route('post.details', $post->slug) }}" />
    <meta property="og:image" content="{{ assetFile($post->meta_image) }}" />
    <meta property="og:description" content="{{ $post->meta_description }}" />
    <meta property="og:site_name" content="{{ env('APP_NAME') }}" />
@endsection
@section('content')
<div class="col-lg-8">
    <div class="blog-details-box">
      <div class="entry-content">
        <a href="{{ route('category.posts',$post->category->slug) }}" class="cat">{{ $post->category->name }}</a>
        <h2 class="title">
            {{ $post->title }}
        </h2>
        <ul class="post-meta">
          <li><a href="{{ route('post.details',$post->slug) }}"><i class="fal fa-user"></i>by {{ $post->user->name }}</a></li>
          <li><a href="{{ route('post.details',$post->slug) }}"><i class="fal fa-calendar-alt"></i>{{ $post->created_at->format('dS M Y') }}</a></li>
          <li><a href="{{ route('post.details',$post->slug) }}"><i class="fal fa-comments"></i>{{ $post->comments->count() }} Comments</a></li>
        </ul>
        <p class="mb-30">
            <img src="{{ assetFile($post->image) }}" alt="">
            {!! $post->description !!}
        </p>
      </div>
      <div class="entry-footer">
        <div class="tag-and-share mt-50 mb-50 d-md-flex align-items-center justify-content-between">
          <div class="tag">
            <h5>Related Tags</h5>
            <ul>
                @foreach (explode(',',$post->tags) as $tag)
                <li><a href="{{ route('search',['tag' => $tag]) }}">{{ $tag }}</a></li>
                @endforeach
            </ul>
          </div>
          <div class="share text-md-right">
            <h5>Social Share</h5>
            <ul>
              <li><a href="https://www.facebook.com/sharer/sharer.php?u={{ route('post.details',$post->slug) }}&display=popup"><i class="fab fa-facebook-f"></i></a></li>
              <li><a href="https://twitter.com/intent/tweet?url={{ route('post.details',$post->slug) }}"><i class="fab fa-twitter"></i></a></li>
              <li><a href="https://www.linkedin.com/shareArticle?mini=true&url={{ route('post.details',$post->slug) }}&t={{ $post->title }}"><i class="fab fa-linkedin"></i></a></li>
              <li><a href="https://plus.google.com/share?url={{ route('post.details',$post->slug) }}"><i class="fab fa-google-plus-g"></i></a></li>
              <li><a href="http://pinterest.com/pin/create/bookmarklet/?url={{ route('post.details',$post->slug) }}&is_video=false&description={{ strip_tags($post->description) }}&media={{ assetFile($post->image) }}"><i class="fab fa-pinterest"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="post-nav d-md-flex align-items-center justify-content-between">
            @isset($previous)
            <div class="prev-post">
                <span>Prev Post</span>
                <a href="{{ route('post.details',$previous->slug) }}">{{ Str::words($previous->title,3) }}</a>
            </div>
            @endisset
            <span class="icon">
                <img src="{{ static_asset('frontend/assets/img/blog-details/icon.png') }}" alt="icon">
            </span>
            @isset($next)
            <div class="next-post text-right">
                <span>Next Post</span>
                <a href="{{ route('post.details',$next->slug) }}">{{ Str::words($next->title,3) }}</a>
            </div>
            @endisset
        </div>
        <div class="related-post mt-50">
          <h3 class="mb-30">Releted Post</h3>
          <div class="row">
            @foreach ($related as $post)
            <div class="col-md-6">
                <div class="related-post-box mb-50">
                  <div class="thumb" style="background-image: url({{ assetFile($post->image) }});">
                  </div>
                  <div class="desc">
                    <a href="{{ route('post.details',$post->slug) }}" class="date">
                        <i class="far fa-calendar-alt"></i>{{ $post->created_at->format('dS M Y') }}</a>
                    <h4>
                        <a href="{{ route('post.details',$post->slug) }}">{{ $post->title }}</a>
                    </h4>
                    <p>{{ Str::words(strip_tags($post->description),6) }}</p>
                  </div>
                </div>
              </div>
            @endforeach
          </div>
        </div>
        <div class="author-info-box mb-45">
          <div class="author-img">
            <img src="{{ assetFile($post->user->image) }}" alt="Image">
          </div>
          <div class="info-text">
            <span>Written by</span>
            <h3>{{ $post->user->name }}</h3>
            <p>
              {{ $post->user->bio }}
            </p>
          </div>
        </div>
      </div>
      <div class="comment-template">
        <h3 class="box-title">{{ $post->comments->count() }} Comments</h3>
        <ul class="comments-list mb-20">
                
            @foreach ($post->comments as $comment)
            <li>
                <div class="comment-img">
                    <img src="{{ assetFile($comment->user->image) }}" alt="img">
                </div>
                <div class="comment-desc">
                    <div class="desc-top">
                        <h6>{{ $comment->user->name }}</h6>
                        <span class="date">{{ $comment->created_at->format('dS M Y') }}</span>
                    </div>
                    <p>
                        {{ $comment->comment }}
                    </p>
                </div>

                <ul class="children">
                    @foreach ($comment->replies as $reply)
                        <li>
                            <div class="comment-img">
                                <img src="{{ assetFile($reply->user->image) }}" alt="img">
                            </div>
                            <div class="comment-desc">
                                <div class="desc-top">
                                    <h6>{{ $reply->user->name }}</h6>
                                    <span class="date">{{ $reply->created_at->format('dS M Y') }}</span>
                                </div>
                                <p>
                                    {{ $reply->reply }}
                                </p>
                            </div>
                        </li>
                    @endforeach
                    @auth
                      <form action="{{ route('comment.reply.store') }}" method="POST">
                          @csrf
                          <input type="hidden" name="post_id" value="{{ $post->id }}">
                          <input type="hidden" name="comment_id" value="{{ $comment->id }}">
                          <h3 class="box-title">{{ Str::words($comment->user->name,1,'') }}'s comments reply..</h3>
                          <textarea placeholder="Type your reply...." name="reply" style="height: 100px"></textarea>
                          <button type="submit" class="btn reply-btn">
                              <i class="far fa-comments"></i> Reply
                          </button>
                      </form>
                    @endauth
                    
                </ul>
            </li>
            @endforeach
        </ul>
        @auth
        <h3 class="box-title">Add Comment</h3>
        <div class="comment-form">
            <form action="{{ route('comment.store') }}" method="POST">
                @csrf
                <input type="hidden" name="post_id" value="{{ $post->id }}">

                <div class="input-group input-group-two textarea mb-20">
                    <textarea placeholder="Type your comments...." name="comment"></textarea>
                    <div class="icon">
                        <i class="fas fa-pen"></i>
                    </div>
                </div>
                <div class="input-group  mt-30">
                    <button type="submit" class="main-btn btn-filled">
                        <i class="far fa-comments"></i> Submit
                    </button>
                </div>
            </form>
        </div>
        @endauth
      </div>
    </div>
  </div>
@endsection