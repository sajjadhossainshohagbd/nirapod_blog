<header class="header-three">
    <div class="header-top">
        <div class="container container-custom-three">
            <div class="d-md-flex align-items-center justify-content-between">
                <ul class="contact-list">
                    <li>
                        <a href="mailto:{{ settings('email_address') }}">
                            <i class="fal fa-envelope"></i>
                            {{ settings('email_address') }}
                        </a>
                    </li>
                    <li>
                        <a href="tel:{{ settings('phone_number') }}">
                            <i class="fal fa-phone"></i>
                            {{ settings('phone_number') }}
                        </a>
                    </li>
                </ul>
                <div class="d-flex align-items-center justify-content-center justify-content-md-end">
                    <!-- search btton -->
                    <div class="search">
                        <a href="#" class="search-icon" id="searchBtn">
                            <i class="fal fa-search open-icon"></i>
                            <i class="fal fa-times close-icon"></i>
                        </a>
                        <div class="search-form">
                            <form action="{{ route('search') }}" method="GET">
                                <input type="text" name="keyword" placeholder="Search your keyword..." value="{{ request('keyword') }}">
                                <button type="submit"><i class="far fa-search"></i></button>
                            </form>
                        </div>
                    </div>
                    <ul class="sigma_social-links justify-content-center">
                        <li><a href="{{ settings('header_fb_link') }}"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="{{ settings('header_twitter_link') }}" class="red-icon"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="{{ settings('header_linkedin_link') }}" class="white-icon"><i class="fab fa-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="main-menu-area sticky-header">
        <div class="container container-custom-three">
            <div class="nav-container d-flex align-items-center justify-content-between">
                <!-- Site Logo -->
                <div class="site-logo">
                    <a href="{{ url('/') }}"><img src="{{ assetFile(settings('header_logo')) }}" height="80" alt="Logo"></a>
                </div>
                <!-- Main Menu -->
                <div class="nav-menu d-lg-flex align-items-center justify-content-between">

                    <!-- Navbar Close Icon -->
                    <div class="navbar-close">
                        <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                    </div>
                    @php
                        $menus = App\Models\Menu::all();
                    @endphp
                    <!-- Mneu Items -->
                    <div class="menu-items">
                        <ul>
                            @foreach ($menus as $menu)
                                <li>
                                    <a href="{{ $menu->link }}">{{ $menu->name }}</a>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
                <!-- Navbar Toggler -->
                <div class="navbar-toggler">
                    <span></span><span></span><span></span>
                </div>
            </div>
        </div>
    </div>
</header>