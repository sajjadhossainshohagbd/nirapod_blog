<section class="room-type-section pt-115 pb-115">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="section-title text-lg-left text-center">
                    <h2>Featured
                        <span class="highlight">
                         Categories
                        </span>
                    </h2>
                </div>
            </div>
        </div>
        <div class="room-items">
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                        @if(isset($categories[0]) && $categories[0] != null)
                        <div class="col-lg-6 col-sm-6">
                            <div class="room-box">
                                <div class="room-bg"
                                    style="background-image: url({{ assetFile($categories[0]->posts->first()?->image) }});">
                                </div>
                                <div class="room-content">
                                    <span class="room-count white">
                                        <i class="fal fa-th"></i>{{ $categories[0]->posts->count() }} Posts
                                    </span>
                                    <h3><a href="{{ route('category.posts',$categories[0]->slug) }}">{{ $categories[0]->name }}</a></h3>
                                </div>
                                <a href="{{ route('category.posts',$categories[0]->slug) }}" class="room-link"><i class="fal fa-arrow-right"></i></a>
                            </div>
                        </div>
                        @endif
                        @if(isset($categories[1]) && $categories[1] != null)
                        <div class="col-lg-6 col-sm-6">
                            <div class="room-box">
                                <div class="room-bg"
                                    style="background-image: url({{ assetFile($categories[1]->posts->first()?->image) }});">
                                </div>
                                <div class="room-content">
                                    <span class="room-count green"><i class="fal fa-th"></i>{{ $categories[1]->posts->count() }} Posts</span>
                                    <h3><a href="{{ route('category.posts',$categories[1]->slug) }}">{{ $categories[1]->name }}</a></h3>
                                </div>
                                <a href="{{ route('category.posts',$categories[1]->slug) }}" class="room-link"><i class="fal fa-arrow-right"></i></a>
                            </div>
                        </div>
                        @endif
                        @if(isset($categories[2]) && $categories[2] != null)
                        <div class="col-12">
                            <div class="room-box extra-wide">
                                <div class="room-bg"
                                    style="background-image: url({{ assetFile($categories[2]->posts->first()?->image) }});"></div>
                                <div class="room-content">
                                    <span class="room-count red"><i class="fal fa-th"></i>{{ $categories[2]->posts->count() }} Posts</span>
                                    <h3><a href="{{ route('category.posts',$categories[2]->slug) }}">{{ $categories[2]->name }}</a></h3>
                                </div>
                                <a href="{{ route('category.posts',$categories[2]->slug) }}" class="room-link"><i class="fal fa-arrow-right"></i></a>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
                @if(isset($categories[3]) && $categories[3] != null)
                <div class="col-lg-4">
                    <div class="room-box extra-height">
                        <div class="room-bg" style="background-image: url({{ assetFile($categories[3]->posts->first()?->image) }});">
                        </div>
                        <div class="room-content">
                            <span class="room-count"><i class="fal fa-th"></i>{{ $categories[3]->posts->count() }} Posts</span>
                            <h3><a href="{{ route('category.posts',$categories[3]->slug) }}">{{ $categories[3]->name }}</a></h3>
                        </div>
                        <a href="{{ route('category.posts',$categories[3]->slug) }}" class="room-link"><i class="fal fa-arrow-right"></i></a>
                    </div>
                </div>
                @endif
            </div>
        </div>
    </div>
</section>