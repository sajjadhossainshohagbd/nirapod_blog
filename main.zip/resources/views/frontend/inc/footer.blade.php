<footer class="footer-two text-center">
    <div class="p-2">
        <div class="col-lg-12 col-sm-12">
            <!-- Site Info Widget -->
            <div class="widget site-info-widget mb-50">
                <div class="footer-logo mb-50">
                    <img src="{{ assetFile(settings('header_logo')) }}" alt="Logo" height="80" class="text-center">
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-area pt-10 pb-30">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12 col-md-10 order-2 order-md-1">
                    <p class="copyright-text copyright-two">{{ settings('copyright_text') }}</p>
                </div>
            </div>
        </div>
    </div>
</footer>