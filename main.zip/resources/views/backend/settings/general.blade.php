@extends('layouts.backend-app')
@section('title')
General Settings
@endsection
@push('js')
<script src="{{ static_asset('backend/js/bootstrap-tagsinput.min.js') }}"></script>
<script>
    $('input[name=seo_site_keywords]').tagsinput();
</script>
@endpush
@push('css')
<link rel="stylesheet" href="{{ static_asset('backend/css/bootstrap-tagsinput.min.css') }}">
@endpush
@section('content')
<div class="row">
    <div class="col-md-11 mx-auto">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">@yield('title')</h6>
            </div>
            <form action="{{ route('store.settings') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="card-body">
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Site title</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="site_title">
                            <input type="text" name="site_title" class="form-control" value="{{ settings('site_title') }}">
                        </div>
                    </div>
                </div>
                <hr>
                <div class="card-header">
                    <h6 class="mb-0">SEO Meta Data</h6>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">title</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="seo_site_title">
                            <input type="text" name="seo_site_title" class="form-control" value="{{ settings('seo_site_title') }}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Description</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="seo_site_description">
                            <textarea name="seo_site_description" class="form-control" id="seo_site_description" cols="80" rows="10">{{ settings('seo_site_description') }}</textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Logo</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="seo_site_logo">
                            <input type="file" name="seo_site_logo" class="form-control">
                            <img src="{{ assetFile(settings('seo_site_logo')) }}" height="100" width="100">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Keywords</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="seo_site_keywords">
                            <input type="text" name="seo_site_keywords" class="form-control" value="{{ settings('seo_site_keywords') }}">
                        </div>
                    </div>
                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
