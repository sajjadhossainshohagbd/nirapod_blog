@extends('layouts.backend-app')
@section('title')
My Profile
@endsection
@section('content')
<div class="row">
    <div class="col-md-11 mx-auto">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">My Profile</h6>
            </div>
            <div class="card-body">
                <form action="{{ route('update.profile') }}" method="POST" enctype="multipart/form-data">
                    @csrf

                    <div class="text-center p-4">
                        <img src="{{ assetFile(auth()->user()->image) }}" alt="" height="100">
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Change Profile Picture</label>
                        <div class="col-md-8">
                            <input type="file" name="profile_pic" class="form-control">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Name</label>
                        <div class="col-md-8">
                            <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" value="{{ auth()->user()->name }}">
                            @error('name')
                                <div class="text-danger">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Bio</label>
                        <div class="col-md-8">
                            <input type="text" name="bio" class="form-control" value="{{ auth()->user()->bio }}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Email Address</label>
                        <div class="col-md-8">
                            <input type="email" name="email" class="form-control " value="{{ auth()->user()->email }}" disabled>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Password</label>
                        <div class="col-md-8">
                            <input type="password" name="password" class="form-control @error('password') is-invalid @enderror" placeholder="Enter Password">
                            @error('password')
                                <div class="text-danger">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Confirm Password</label>
                        <div class="col-md-8">
                            <input type="password" name="password_confirmation" class="form-control" placeholder="Enter Confirm Password">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Facebook Link</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="fb_link">
                            <input type="text" name="fb_link" class="form-control " value="{{ isset(auth()->user()->social_links->fb_link) }}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Twitter Link</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="twitter_link">
                            <input type="text" name="twitter_link" class="form-control " value="{{ isset(auth()->user()->social_links->twitter_link) }}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Instagram Link</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="instagram_link">
                            <input type="text" name="instagram_link" class="form-control " value="{{ isset(auth()->user()->social_links->instagram_link) }}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">YouTube Link</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="youtube_link">
                            <input type="text" name="youtube_link" class="form-control " value="{{ isset(auth()->user()->social_links->youtube_link) }}">
                        </div>
                    </div>
                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
