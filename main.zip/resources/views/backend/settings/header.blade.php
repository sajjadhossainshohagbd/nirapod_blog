@extends('layouts.backend-app')
@section('title')
Header Settings
@endsection
@section('content')
<div class="row">
    <div class="col-md-11 mx-auto">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">Header Setting</h6>
            </div>
            <div class="card-body">
                <form action="{{ route('store.settings') }}" method="POST" enctype="multipart/form-data">
                    @csrf

                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Header Logo</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="header_logo">
                            <input type="file" name="header_logo" class="form-control">
                            <img src="{{ assetFile(settings('header_logo')) }}"id="preview-logo" height="100" width="100">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Site Icon</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="site_icon">
                            <input type="file" name="site_icon" class="form-control">
                            <img src="{{ assetFile(settings('site_icon')) }}" id="preview-logo" height="100" width="100">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Email Address</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="email_address">
                            <input type="email" name="email_address" class="form-control" value="{{ settings('email_address') }}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Phone Number</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="phone_number">
                            <input type="number" name="phone_number" class="form-control" value="{{ settings('phone_number') }}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Facebook Link</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="header_fb_link">
                            <input type="url" name="header_fb_link" class="form-control" value="{{ settings('header_fb_link') }}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Twitter Link</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="header_twitter_link">
                            <input type="url" name="header_twitter_link" class="form-control" value="{{ settings('header_twitter_link') }}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">LinkedIn Link</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="header_linkedin_link">
                            <input type="url" name="header_linkedin_link" class="form-control" value="{{ settings('header_linkedin_link') }}">
                        </div>
                    </div>
                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
