@extends('layouts.backend-app')
@section('title')
Menus Settings
@endsection
@section('content')
<div class="row">
    <div class="col-md-11 mx-auto">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">Menus Setting</h6>
            </div>
            <div class="card-body">
                <form action="{{ route('menu.store') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group row">
                        <div class="col-md-2">
                            <input type="text" name="name" class="form-control" placeholder="Menu Name" required>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="link" class="form-control" placeholder="Menu Link" required>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary">Add Menu</button>
                        </div>
                    </div>
                </form>
                <hr>
                @php
                    $menus = App\Models\Menu::all();
                @endphp
                @foreach($menus as $menu)
                    <form action="{{ route('update.menu',encrypt($menu->id)) }}" method="POST">
                        @csrf
                        <div class="form-group row">
                            <div class="col-md-2">
                                <input type="text" name="name" class="form-control" placeholder="Menu Name" value="{{ $menu->name }}">
                            </div>
                            <div class="col-md-6">
                                <input type="url" name="link" class="form-control" placeholder="Menu Link" value="{{ $menu->link }}">
                            </div>
                            <div class="col-md-4">
                                <a href="{{ route('delete.menu',encrypt($menu->id)) }}" onclick="return confirm('Are you sure?')" class="btn btn-danger"> <i class="fa fa-trash"></i> </a>
                                <button type="submit" class="btn btn-primary">Update Menu</button>
                            </div>
                        </div>
                    </form>
                @endforeach
            </div>
        </div>
    </div>
</div>
@endsection
