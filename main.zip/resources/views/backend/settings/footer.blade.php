@extends('layouts.backend-app')
@section('title')
Footer Settings
@endsection
@section('content')
<div class="row">
    <div class="col-md-11 mx-auto">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">Footer Setting</h6>
            </div>
            <div class="card-body">
                <form action="{{ route('store.settings') }}" method="POST" enctype="multipart/form-data">
                    @csrf

                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Copyright Text</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="copyright_text">
                            <input type="text" name="copyright_text" class="form-control" value="{{ settings('copyright_text') }}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Facebook Link</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="footer_fb_link">
                            <input type="url" name="footer_fb_link" class="form-control" value="{{ settings('footer_fb_link') }}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Twitter Link</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="footer_twitter_link">
                            <input type="url" name="footer_twitter_link" class="form-control" value="{{ settings('footer_twitter_link') }}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">SoundCloud Link</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="footer_soundcloud_link">
                            <input type="url" name="footer_soundcloud_link" class="form-control" value="{{ settings('footer_soundcloud_link') }}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">Instagram Link</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="footer_instagram_link">
                            <input type="url" name="footer_instagram_link" class="form-control" value="{{ settings('footer_instagram_link') }}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-from-label">YouTube Link</label>
                        <div class="col-md-8">
                            <input type="hidden" name="types[]" value="footer_youtube_link">
                            <input type="url" name="footer_youtube_link" class="form-control" value="{{ settings('footer_youtube_link') }}">
                        </div>
                    </div>
                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
