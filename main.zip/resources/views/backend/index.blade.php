@extends('layouts.backend-app')

@section('title')
Admin Dashboard
@endsection
@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-xl-4  col-sm-8">
            <div class="card">
                <div class="card-body">
                    <div class="media align-items-center">
                        <div class="media-body mr-3">
                            <h2 class="fs-34 text-black font-w600">{{ $post_count }}</h2>
                            <span>Total Posts</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4  col-sm-8">
            <div class="card">
                <div class="card-body">
                    <div class="media align-items-center">
                        <div class="media-body mr-3">
                            <h2 class="fs-34 text-black font-w600">{{ $total_comments }}</h2>
                            <span>Total Comments</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4  col-sm-8">
            <div class="card">
                <div class="card-body">
                    <div class="media align-items-center">
                        <div class="media-body mr-3">
                            <h2 class="fs-34 text-black font-w600">{{ $total_categories }}</h2>
                            <span>Total Categories</span>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Top 10 Posts</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-responsive-sm">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Category</th>
                                    <th>Title</th>
                                    <th>Total Visitor</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($posts as $post)
                                    <tr>
                                        <td>
                                            <a href="{{ route('post.details',$post->slug) }}" target="_blank">
                                                <img src="{{ assetFile($post->image) }}" alt="{{ $post->title }}" height="60" width="60">
                                            </a>
                                        </td>
                                        <td>
                                            <a href="{{ route('post.details',$post->slug) }}" target="_blank">
                                                {{ $post->category->name }}
                                            </a>
                                        </td>
                                        <td>
                                            <a href="{{ route('post.details',$post->slug) }}" target="_blank">
                                                {{ $post->title }}
                                            </a>
                                        </td>	
                                        <td>
                                            {{ $post->visitors_count }}
                                        </td>										
                                    </tr>
                                @empty
                                    <td colspan="4" class="text-center">No Posts Found!</td>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection