<div class="deznav">
    <div class="deznav-scroll">
        <ul class="metismenu" id="menu">
            <li>
                <a class="ai-icon" href="{{ route('dashboard') }}" aria-expanded="false">
                    <i class="flaticon-381-networking"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li>
                <a class="ai-icon" href="{{ route('categories') }}" aria-expanded="false">
                    <i class="fa fa-list"></i>
                    <span class="nav-text">Category</span>
                </a>
            </li>
            <li>
                <a class="ai-icon" href="{{ route('posts') }}" aria-expanded="false">
                    <i class="fa fa-feed"></i>
                    <span class="nav-text">Posts</span>
                </a>
            </li>
            <li>
                <a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="true">
                    <i class="flaticon-381-television"></i>
                    <span class="nav-text">Settings</span>
                </a>
                <ul aria-expanded="false" class="mm-collapse" style="">
                    <li><a href="{{ route('general.settings') }}">General</a></li>
                    <li><a href="{{ route('header.settings') }}">Header</a></li>
                    <li><a href="{{ route('footer.settings') }}">Footer</a></li>
                    <li><a href="{{ route('menus.settings') }}">Menus</a></li>
                </ul>
            </li>
        </ul>
    </div>
</div>