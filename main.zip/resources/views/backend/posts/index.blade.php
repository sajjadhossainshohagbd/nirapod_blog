@extends('layouts.backend-app')
@section('title')
Posts
@endsection
@push('js')
    <script src="{{ static_asset('backend/js/bootstrap-tagsinput.min.js') }}"></script>
    {{-- <script src="https://cdn.ckeditor.com/ckeditor5/33.0.0/classic/ckeditor.js"></script> --}}
    <script src="https://cdn.ckeditor.com/4.17.2/standard/ckeditor.js"></script>
    <script src="{{ static_asset('backend/vendor/select2/js/select2.full.min.js') }}"></script>
    <script>
        window.uploadUrl = "{{ route('image.store',['_token' => csrf_token()]) }}"
    </script>
    <script src="{{ static_asset('backend/js/custom/posts.js') }}"></script>
@endpush
@push('css')
    <link rel="stylesheet" href="{{ static_asset('backend/css/bootstrap-tagsinput.min.css') }}">
    <link rel="stylesheet" href="{{ static_asset('backend/vendor/select2/css/select2.min.css') }}">
@endpush
@section('content')
<div class="container-fluid">
    <div class="form-head align-items-center d-flex mb-sm-4 mb-3">
        <div>
            <a href="javascript:void(0)" class="btn btn-primary mr-3" data-toggle="modal" data-target="#addPost">+ New Post</a>
        </div>
    </div>
    <!-- Add Post -->
    <div class="modal fade" id="addPost">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Post</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('post.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label class="text-black font-w500">Title <small>(Required)</small></label>
                            <input type="text" class="form-control" name="title" required>
                        </div>
                        <div class="form-group">
                            <label class="text-black font-w500">Category <small>(Required)</small></label>
                            <select name="category_id" id="category_id" class="form-control">
                                <option value="" disabled selected>Select Category</option>
                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="text-black font-w500">Description <small>(Required)</small></label>
                            <textarea name="description" id="description" class="form-control" cols="30" rows="5"></textarea>
                        </div>
                        <div class="form-group">
                            <label class="text-black font-w500">Image <small>(Required)</small></label>
                            <input type="file" class="form-control" name="image" accept="image/*" required>
                        </div>
                        <div class="form-group">
                            <label class="text-black font-w500">Tags <small>(Required)</small></label> <br>
                            <input type="text" class="form-control" name="tags" id="tags" required>
                        </div>
                        <div id="accordion-seven" class="accordion accordion-active-header">
                            <div class="accordion__item">
                                <div class="accordion__header collapsed accordion__header--success" data-toggle="collapse" data-target="#header-bg_collapseThree">
                                    <span class="accordion__header--icon"></span>
                                    <span class="accordion__header--text">Meta Data</span>
                                    <span class="accordion__header--indicator"></span>
                                </div>
                                <div id="header-bg_collapseThree" class="collapse accordion__body" data-parent="#accordion-seven">
                                    <div class="accordion__body--text">
                                        <div class="form-group">
                                            <label class="text-black font-w500">Meta Title</label>
                                            <input type="text" class="form-control" name="meta_title">
                                        </div>
                                        <div class="form-group">
                                            <label class="text-black font-w500">Meta Description</label>
                                            <textarea name="meta_description" id="meta_description" class="form-control" cols="30" rows="5"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label class="text-black font-w500">Meta Image</label>
                                            <input type="file" class="form-control" name="meta_image" accept="image/*" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-success">Add Post</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    {{-- Edit Post --}}
    <div class="modal fade" id="editPost">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Post</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">@yield('title')</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-responsive-sm">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Category</th>
                                    <th>Title</th>
                                    <th>Total Visitors</th>
                                    <th style="width:300px">Options</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($posts as $post)
                                    <tr>
                                        <td>
                                            <img src="{{ assetFile($post->image) }}" alt="{{ $post->title }}" height="60" width="60">
                                        </td>
                                        <td>{{ $post->category->name }}</td>
                                        <td>{{ $post->title }}</td>
                                        <td>
                                            {{ $post->visitors_count }}
                                        </td>
                                        <td>
                                            <a href="javascript:void(0)" class="btn btn-success" onclick="editPost(this)" data-url="{{ route('post.edit',encrypt($post->id)) }}">Edit</a>
                                            <a href="{{ route('post.delete',encrypt($post->id)) }}" onclick="return confirm('Are you sure delete?')" class="btn btn-danger">Delete</a>
                                        </td>
                                        												
                                    </tr>
                                @empty
                                    <td colspan="4" class="text-center">No Posts Found!</td>
                                @endforelse
                            </tbody>
                        </table>
                        {{ $posts->links('pagination::bootstrap-5') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection