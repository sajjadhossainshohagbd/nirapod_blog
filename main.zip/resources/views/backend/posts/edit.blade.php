<form action="{{ route('post.update',encrypt($post->id)) }}" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="form-group">
        <label class="text-black font-w500">Title <small>(Required)</small></label>
        <input type="text" class="form-control" name="title" value="{{ $post->title }}" required>
    </div>
    <div class="form-group">
        <label class="text-black font-w500">Category <small>(Required)</small></label>
        <select name="category_id" id="category_id" class="form-control">
            <option value="" disabled selected>Select Category</option>
            @foreach ($categories as $category)
                <option value="{{ $category->id }}" @selected($category->id == $post->category_id)>{{ $category->name }}</option>
            @endforeach
        </select>
    </div>
    <div class="form-group">
        <label class="text-black font-w500">Description <small>(Required)</small></label>
        <textarea name="description" id="description" class="form-control" cols="30" rows="5">{!! $post->description !!}</textarea>
    </div>
    <div class="form-group">
        <label class="text-black font-w500">Image </label>
        <input type="file" class="form-control" name="image" accept="image/*">
        <div class="mt-2">
            <img src="{{ assetFile($post->image) }}" alt="" height="100" width="100">
        </div>
    </div>
    <div class="form-group">
        <label class="text-black font-w500">Tags <small>(Required)</small></label> <br>
        <input type="text" class="form-control" name="tags" id="edit_tags" value="{{ $post->tags }}" required>
    </div>
    <div id="accordion-seven" class="accordion accordion-active-header">
        <div class="accordion__item">
            <div class="accordion__header collapsed accordion__header--success" data-toggle="collapse" data-target="#header-bg_collapseThree">
                <span class="accordion__header--icon"></span>
                <span class="accordion__header--text">Meta Data</span>
                <span class="accordion__header--indicator"></span>
            </div>
            <div id="header-bg_collapseThree" class="collapse accordion__body" data-parent="#accordion-seven">
                <div class="accordion__body--text">
                    <div class="form-group">
                        <label class="text-black font-w500">Meta Title</label>
                        <input type="text" class="form-control" name="meta_title" value="{{ $post->meta_title }}">
                    </div>
                    <div class="form-group">
                        <label class="text-black font-w500">Meta Description</label>
                        <textarea name="meta_description" id="meta_description" class="form-control" cols="30" rows="5">{!! $post->meta_description !!}</textarea>
                    </div>
                    <div class="form-group">
                        <label class="text-black font-w500">Meta Image</label>
                        <input type="file" class="form-control" name="meta_image" accept="image/*" >
                        <div class="mt-2">
                            <img src="{{ assetFile($post->image) }}" alt="" height="100" width="100">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-success">Update Post</button>
    </div>
</form>

<script>
    $('#edit_tags').tagsinput();
</script>