<form action="{{ route('category.update',encrypt($category->id)) }}" method="POST">
    @csrf
    
    <div class="form-group">
        <label class="text-black font-w500">Category Name <small>(Required)</small></label>
        <input type="text" class="form-control" name="name" value="{{ $category->name }}" required>
    </div>
    <div class="form-group">
        <label class="text-black font-w500" for="is_featured">Is Featured</label>
        <select  class="form-control" name="is_featured" id="edit_is_featured" required>
            <option value="0" @selected($category->is_featured == 0)>No</option>
            <option value="1" @selected($category->is_featured == 1)>Yes</option>
        </select>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-success">Update Category</button>
    </div>
</form>