@extends('layouts.backend-app')
@section('title')
Categories
@endsection
@push('js')
    <script src="{{ static_asset('backend/js/custom/categories.js') }}"></script>
@endpush
@section('content')
<div class="container-fluid">
    <div class="form-head align-items-center d-flex mb-sm-4 mb-3">
        <div>
            <a href="javascript:void(0)" class="btn btn-primary mr-3" data-toggle="modal" data-target="#addCategory">+New Category</a>
        </div>
    </div>
    <!-- Add Category -->
    <div class="modal fade" id="addCategory">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Category</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('category.store') }}" method="POST">
                        @csrf
                        <div class="form-group">
                            <label class="text-black font-w500">Category Name <small>(Required)</small></label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="form-group">
                            <label class="text-black font-w500" for="is_featured">Is Featured</label>
                            <select  class="form-control" name="is_featured" id="is_featured" required>
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-success">Add Category</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    {{-- Edit Category --}}
    <div class="modal fade" id="editCategory">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Category</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">@yield('title')</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-responsive-sm">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Featured</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($categories as $category)
                                    <tr>
                                        <td>{{ $category->name }}</td>
                                        <td>
                                            <span class="badge badge-outline-primary">
                                                @if($category->is_featured)
                                                <i class="fa fa-circle text-primary mr-1"></i>
                                                Yes
                                                @else
                                                <i class="fa fa-circle text-danger mr-1"></i>
                                                No
                                                @endif
                                            </span>
                                        </td>
                                        <td>
                                            <a href="javascript:void(0)" class="btn btn-success" onclick="editCategory(this)" data-url="{{ route('category.edit',encrypt($category->id)) }}">Edit</a>
                                            <a href="{{ route('category.delete',encrypt($category->id)) }}" onclick="return confirm('Are you sure delete?')" class="btn btn-danger">Delete</a>
                                        </td>												
                                    </tr>
                                @empty
                                    <td colspan="4" class="text-center">No Category Found!</td>
                                @endforelse
                            </tbody>
                        </table>
                        {{ $categories->links('pagination::bootstrap-5') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection