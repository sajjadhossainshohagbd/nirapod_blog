<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title> @yield('title') {{ settings('site_title') }}</title>
	<meta name="robots" content="index, follow">
    <meta name="description" content="{{ settings('seo_site_description') }}" />
    <meta name="keywords" content="{{ settings('seo_site_keywords') }}">
	@yield('meta')
	<!--====== Favicon Icon ======-->
	<link rel="shortcut icon" href="{{ assetFile(settings('site_icon')) }}" type="img/png" />
	<!--====== Animate Css ======-->
	<link rel="stylesheet" href="{{ static_asset('frontend/assets/css/animate.min.css') }}">
	<!--====== Bootstrap css ======-->
	<link rel="stylesheet" href="{{ static_asset('frontend/assets/css/bootstrap.min.css') }}" />
	<!--====== Fontawesome css ======-->
	<link rel="stylesheet" href="{{ static_asset('frontend/assets/css/font-awesome.min.css') }}" />
	<!--====== Flaticon css ======-->
	<link rel="stylesheet" href="{{ static_asset('frontend/assets/fonts/flaticon/flaticon.css') }}" />
	<!--====== Magnific Popup css ======-->
	<link rel="stylesheet" href="{{ static_asset('frontend/assets/css/magnific-popup.css') }}" />
	<!--====== Owl Carousel css ======-->
	<link rel="stylesheet" href="{{ static_asset('frontend/assets/css/slick.css') }}" />
	<!--====== Nice Select ======-->
	<link rel="stylesheet" href="{{ static_asset('frontend/assets/css/nice-select.css') }}" />
	<!--====== Bootstrap Datepicker ======-->
	<link rel="stylesheet" href="{{ static_asset('frontend/assets/css/bootstrap-datepicker.css') }}" />
	<!--====== Default css ======-->
	<link rel="stylesheet" href="{{ static_asset('frontend/assets/css/default.css') }}" />
	<!--====== Style css ======-->
	<link rel="stylesheet" href="{{ static_asset('frontend/assets/css/style.css') }}" />
</head>
<body>
    <!--[if lte IE 9]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
	<![endif]-->

    @include('frontend.inc.header')

	@if(Route::is('home'))
	@include('frontend.inc.featured-categories')
	@endif
	<!--====== BLOG SECTION START ======-->
	<section class="blog-section pt-100 pb-120">
		<div class="container">
			<div class="row justify-content-center">
				@yield('content')
				<!-- Blog Sidebar -->
				<div class="col-lg-4 col-md-8 col-sm-10">
					<div class="sidebar">
						@php
							$super_admin = App\Models\User::where('user_type','super_admin')->first();
						@endphp
						<!-- About Author Widget -->
						<div class="widget about-author-widget mb-40">
							<h5 class="widget-title">About Me</h5>
							<div class="author-box">
								<img src="{{ assetFile($super_admin->image) }}" alt="author" height="300" style="border-radius: 100px">
								<h6>{{ $super_admin->name }}</h6>
								<p>{{ $super_admin->bio }}</p>
								
								<ul class="social-icon">
									<li><a href="{{ @$super_admin->social_links->fb_link }}"><i class="fab fa-facebook-f"></i></a></li>
									<li><a href="{{ @$super_admin->social_links->twitter_link }}"><i class="fab fa-twitter"></i></a></li>
									<li><a href="{{ @$super_admin->social_links->instagram_link }}"><i class="fab fa-instagram"></i></a></li>
									<li><a href="{{ @$super_admin->social_links->youtube_link }}"><i class="fab fa-youtube"></i></a></li>
								</ul>
							</div>
						</div>
						<!-- Search Widget -->
						<div class="widget search-widget mb-40">
							<h5 class="widget-title">Search</h5>
							<form action="{{ route('search') }}" method="GET">
								<input type="text" name="keyword" placeholder="Search your keyword..." value="{{ request('keyword') }}">
								<button type="submit"><i class="far fa-search"></i></button>
							</form>
						</div>
						<!-- Popular Post Widget -->
						@php
							$popular = App\Models\Post::withCount('visitors')->orderByDesc('visitors_count')->paginate(10);
							$popular_tags = App\Models\Post::withCount('visitors')->orderByDesc('visitors_count')->pluck('tags');
						@endphp
						<div class="widget popular-feeds mb-40">
							<h5 class="widget-title">Popular Posts</h5>
							<div class="popular-feed-loop">
								@foreach($popular as $post)
								<div class="single-popular-feed">
									<div class="feed-img">
										<img src="{{ assetFile($post->image) }}" alt="Image">
									</div>
									<div class="feed-desc">
										<h6><a href="{{ route('post.details',$post->slug) }}">{{ $post->title }}</a></h6>
										<span class="time">
											<i class="far fa-calendar-alt"></i> {{ $post->created_at->format('dS M Y') }}
										</span>
									</div>
								</div>
								@endforeach
							</div>
						</div>
						<!-- Categories Widget -->
						<div class="widget categories-widget mb-40">
							<h5 class="widget-title">Categories</h5>
							@php
								$categories = App\Models\Category::with('posts')->take(5)->get();
							@endphp
							<ul>
								@foreach ($categories as $category)
								<li>
									<a href="{{ route('category.posts',$category->slug) }}">{{ $category->name }}<span>{{ $category->posts->count() }}</span></a>
								</li>
								@endforeach
							</ul>
						</div>
						<!-- Social Icon Widget -->
						<div class="widget socail-widget mb-40">
							<h5 class="widget-title">Never Miss Blog</h5>
							<ul>
								<li><a href="{{ settings('header_fb_link') }}"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="{{ settings('header_twitter_link') }}"><i class="fab fa-twitter"></i></a></li>
								<li><a href="{{ settings('header_linkedin_link') }}"><i class="fab fa-linkedin"></i></a></li>
								<li><a href="{{ settings('header_youtube_link') }}"><i class="fab fa-youtube"></i></a></li>
							</ul>
						</div>
						<!-- Popular Tags Widget -->
						<div class="widget popular-tag-widget mb-40">
							<h5 class="widget-title">Popular Tags</h5>
							<ul>
								@foreach($popular_tags as $tag)
									@foreach(explode(',',$tag) as $t)
										<li><a href="{{ route('search',['tag' => $t]) }}">{{ $t }}</a></li>
									@endforeach
								@endforeach
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--====== BLOG SECTION END ======-->
	<!--====== SOCAIL SHARE PART START ======-->
	<div class="instagram-feed-section style-2">
		<div class="container-fluid p-0">
			<div class="row no-gutters">
				<div class="col-lg col-sm-6">
					<a href="{{ settings('footer_fb_link') }}" class="facebook social-box">
						Facebook
						<i class="fab fa-facebook-f"></i>
					</a>
				</div>
				<div class="col-lg col-sm-6">
					<a href="{{ settings('footer_instagram_link') }}" class="instagram social-box">
						Instagram
						<i class="fab fa-instagram"></i>
					</a>
				</div>
				<div class="col-lg col-sm-6">
					<a href="{{ settings('footer_soundcloud_link') }}" class="soundcloud social-box">
						Soundcloud
						<i class="fab fa-soundcloud"></i>
					</a>
				</div>
				<div class="col-lg col-sm-6">
					<a href="{{ settings('footer_twitter_link') }}" class="twitter social-box">
						Twitter
						<i class="fab fa-twitter"></i>
					</a>
				</div>
				<div class="col-lg">
					<a href="{{ settings('footer_youtube_link') }}" class="youtube social-box">
						Youtube
						<i class="fab fa-youtube"></i>
					</a>
				</div>
			</div>
		</div>
	</div>
	<!--====== SOCAIL SHARE PART END ======-->
	<!--====== Back to Top ======-->
	<a href="#" class="back-to-top" id="backToTop">
		<i class="fal fa-angle-double-up"></i>
	</a>
	<!--====== FOOTER PART START ======-->
    @include('frontend.inc.footer')
	<!--====== FOOTER PART END ======-->
	{{-- <!--====== Modal Popup Start ======-->
	<!-- The Modal -->
	<div class="modal fade on-load-modal" id="myModal">
		<div class="modal-dialog modal-dialog-centeRed">
			<div class="modal-content" style="background-image: url(frontend/assets/img/popup.jpg)">
				<!-- Modal Header -->
				<div class="modal-header">
					<button type="button" class="close popup-trigger" data-dismiss="modal">&times;</button>
				</div>
				<!-- Modal body -->
				<div class="modal-body">
					<div class="modal-inner">
						<h3 class="title">Newsletter</h3>
						<p>Subscribe to our newsletter to recieve exclusive offers</p>

						<form>
							<input type="email" placeholder="Email Address" name="email" value="">
							<button type="submit" class="main-btn btn-filled" name="button">Subscribe</button>
						</form>

					</div>
				</div>
			</div>
		</div>
	</div>
	<!--====== Modal Popup End ======--> --}}
</body>
    <!--====== jquery js ======-->
    <script src="{{ static_asset('frontend/assets/js/vendor/modernizr-3.6.0.min.js') }}"></script>
    <script src="{{ static_asset('frontend/assets/js/vendor/jquery-1.12.4.min.js') }}"></script>
    <!--====== Bootstrap js ======-->
    <script src="{{ static_asset('frontend/assets/js/bootstrap.min.js') }}"></script>
    <script src="{{ static_asset('frontend/assets/js/popper.min.js') }}"></script>
    <!--====== Slick js ======-->
    <script src="{{ static_asset('frontend/assets/js/slick.min.js') }}"></script>
    <!--====== Isotope js ======-->
    <script src="{{ static_asset('frontend/assets/js/isotope.pkgd.min.js') }}"></script>
    <!--====== Magnific Popup js ======-->
    <script src="{{ static_asset('frontend/assets/js/jquery.magnific-popup.min.js') }}"></script>
    <!--====== inview js ======-->
    <script src="{{ static_asset('frontend/assets/js/jquery.inview.min.js') }}"></script>
    <!--====== counterup js ======-->
    <script src="{{ static_asset('frontend/assets/js/jquery.countTo.js') }}"></script>
    <!--====== Nice Select ======-->
    <script src="{{ static_asset('frontend/assets/js/jquery.nice-select.min.js') }}"></script>
    <!--====== Bootstrap datepicker ======-->
    <script src="{{ static_asset('frontend/assets/js/bootstrap-datepicker.js') }}"></script>
    <!--====== Ion Rangeslider ======-->
    <script src="{{ static_asset('frontend/assets/js/ion.rangeSlider.min.js') }}"></script>
    <!--====== Wow JS ======-->
    <script src="{{ static_asset('frontend/assets/js/wow.min.js') }}"></script>
    <!--====== Google Map ======-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC3Ip9iVC0nIxC6V14CKLQ1HZNF_65qEQ"></script>
    <script src="{{ static_asset('frontend/assets/js/map.js') }}"></script>
    <!--====== Main js ======-->
    <script src="{{ static_asset('frontend/assets/js/main.js') }}"></script>
</html>
