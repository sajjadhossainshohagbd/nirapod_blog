<?php

namespace Database\Seeders;

use App\Models\Menu;
use App\Models\Settings;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SettingsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Settings::insert([
            [
                'type' => 'email_address',
                'value' => 'example@example.com'
            ],
            [
                'type' => 'phone_number',
                'value' => 0100000000000
            ],
            [
                'type' => 'header_logo',
                'value' => 'uploads/settings/logo.jpg'
            ]

        ]);

        Menu::insert([
            'name' => 'Home',
            'link' => url('/')
        ]);
    }
}
