(function ($) {
    "use strict"
    var notify = {
        error: function(text){
            toastr.error(text, "Error!", {
                timeOut: 5000,
                closeButton: !0,
                progressBar: !0,
                positionClass: "toast-top-right",
                showDuration: "300",
                hideDuration: "1000",
                extendedTimeOut: "1000",
                showEasing: "swing",
                hideEasing: "linear",
                showMethod: "fadeIn",
                hideMethod: "fadeOut",
            });
        },
        success: function(text){
            toastr.error(text, "Congratulations!", {
                timeOut: 5000,
                closeButton: !0,
                progressBar: !0,
                positionClass: "toast-top-right",
                showDuration: "300",
                hideDuration: "1000",
                extendedTimeOut: "1000",
                showEasing: "swing",
                hideEasing: "linear",
                showMethod: "fadeIn",
                hideMethod: "fadeOut",
            });
        }
    }
})(jQuery);