var notify = {
    error: function(text){
        toastr.error(text, "Error!", {
            timeOut: 5000,
            closeButton: !0,
            progressBar: !0,
            positionClass: "toast-top-right",
            showDuration: "300",
            hideDuration: "1000",
            extendedTimeOut: "1000",
            showEasing: "swing",
            hideEasing: "linear",
            showMethod: "fadeIn",
            hideMethod: "fadeOut",
        });
    },
    success: function(text){
        toastr.success(text, "Congratulations!", {
            timeOut: 5000,
            closeButton: !0,
            progressBar: !0,
            positionClass: "toast-top-right",
            showDuration: "300",
            hideDuration: "1000",
            extendedTimeOut: "1000",
            showEasing: "swing",
            hideEasing: "linear",
            showMethod: "fadeIn",
            hideMethod: "fadeOut",
        });
    }
}
var app = {
    load: function(){
        $('#preloader').hide();
        $('#preloader').fadeOut(500);
        $('#main-wrapper').addClass('show');
        $('#main-wrapper').removeClass('hide');
    },
    loading: function(){
        $('#preloader').show();
        $('#main-wrapper').addClass('hide');
        $('#main-wrapper').removeClass('show');
    }
}
app.load();

$('#is_featured').selectpicker();
$('#edit_is_featured').selectpicker();

