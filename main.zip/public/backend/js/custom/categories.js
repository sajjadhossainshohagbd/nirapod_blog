
function editCategory(el){
    url = $(el).data('url');
    $.ajax({
        url : url,
        type : 'GET',
        beforeSend: function(){
            app.loading();
        },
        success: function(response){
            $("#editCategory>.modal-dialog>.modal-content>.modal-body").html(response);
            app.load();
            $('#editCategory').modal('show');
        },
        error: function(error){
            app.load();
            if(error.status == 404){
                notify.error('Sorry, Category not found!');
            }else{
                notify.error('Sorry, Something went wrong!');
            }
            
        }
    });
}