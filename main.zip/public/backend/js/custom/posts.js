CKEDITOR.replace('description', {
    filebrowserUploadUrl: window.uploadUrl,
    filebrowserUploadMethod: 'form'
});
CKEDITOR.replace('meta_description', {
    filebrowserUploadUrl: window.uploadUrl,
    filebrowserUploadMethod: 'form'
});
$('input[name=tags]').tagsinput();
$('#category_id').select2();
function editPost(el){
    url = $(el).data('url');
    $.ajax({
        url : url,
        type : 'GET',
        beforeSend: function(){
            app.loading();
        },
        success: function(response){
            $("#editPost>.modal-dialog>.modal-content>.modal-body").html(response);
            app.load();
            $('#editPost').modal('show');
        },
        error: function(error){
            app.load();
            if(error.status == 404){
                notify.error('Sorry, Category not found!');
            }else{
                notify.error('Sorry, Something went wrong!');
            }
            
        }
    });
}