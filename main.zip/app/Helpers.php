<?php

use App\Models\Settings;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Storage;

if(!function_exists('slug')){
    function slug($string){
        $slug = Str::slug($string,'-');
        return $slug;
    }
}
if(!function_exists('assetFile')){
    function assetFile($path){
        $location = url(Storage::url('app/'.$path));
        return $location;
    }
}
if(!function_exists('assetUrl')){
    function assetUrl(){
        $url = preg_replace('/([^:])(\/{2,})/', '$1/',env('APP_URL').'/public');
        return $url;
    }
}
if(!function_exists('static_asset')){
    function static_asset($path, $secure = null)
    {
        return app('url')->asset('public/' . $path, $secure);
    }
}

if(!function_exists('settings')){
    function settings($type){
        $settings = Cache::remember($type,3600,function()use($type){
            return Settings::where('type',$type)->first()?->value;
        });

        return $settings;
    }
}

if(!function_exists('shortNumber')){
    function shortNumber($num)
    {
        $units = ['', 'K', 'M', 'B', 'T'];
        for ($i = 0; $num >= 1000; $i++) {
            $num /= 1000;
        }
        return round($num, 1) . $units[$i];
    }
}
if(!function_exists('setEnvValue')){
    function setEnvValue($key, $value){
        $path = app()->environmentFilePath();
        $env = file_get_contents($path);
        $old_value = env($key);
        if (!str_contains($env, $key.'=')) {
            $env .= sprintf("%s=%s\n", $key, $value);
        } else if ($old_value) {
            $env = str_replace(sprintf('%s=%s', $key, $old_value), sprintf('%s=%s', $key, $value), $env);
        } else {
            $env = str_replace(sprintf('%s=', $key), sprintf('%s=%s',$key, $value), $env);
        }
        file_put_contents($path, $env);
        Artisan::call('config:clear');
    }
}
