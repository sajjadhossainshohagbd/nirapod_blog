<?php

namespace App\Console\Commands;

use ZipArchive;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Artisan;

class DataRestore extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'db:restore';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Restoring dummy data...';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        self::removeFolders();
        self::dropAll();

        $this->warn('Folders & All Tables dropped successfully!');

        self::Restore();

        $this->info('Database restored successfully!');

    }

    public function removeFolders()
    {
        File::deleteDirectory(storage_path('app/uploads'));
    }

    public function dropAll()
    {
        Artisan::call('db:wipe');
    }

    public function Restore()
    {
        $zip = new ZipArchive;
        $zip->open(storage_path('app/uploads.zip'));
        $zip->extractTo(storage_path('app'));
        
        DB::unprepared(file_get_contents(base_path('blog.sql')));
    }
}
