<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;

class SettingsController extends Controller
{
    public function header()
    {
        return view('backend.settings.header');
    }

    public function store(Request $request)
    {
        foreach($request->types as $type){
            $settings = Settings::where('type',$type)->first();
            if($settings == null){
                $settings = new Settings();
            }
            $settings->type = $type;
            if($request->hasFile($type)){
                $value = $request->file($type)->store("uploads/settings");
            }else{
                $value = $request[$type] ?? $settings->value;
            }
            if($type == 'site_title'){
                setEnvValue('APP_NAME','"'.$request[$type].'"');
            }
            $settings->value =  $value;
            $settings->save();
        }
        Artisan::call('cache:clear');
        return back()->with('success','Settings Updated Successfully!');
    }

    public function footer()
    {
        return view('backend.settings.footer');
    }

    public function menus()
    {
        return view('backend.settings.menus');
    }
    public function general()
    {
        return view('backend.settings.general');
    }
}
