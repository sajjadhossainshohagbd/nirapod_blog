<?php

namespace App\Http\Controllers\Backend;

use App\Models\Post;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Comment;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;


class HomeController extends Controller
{
    public function index()
    {
        $post_count = Post::count();
        $total_comments = Comment::count();
        $total_categories = Category::count();
        $posts = Post::withCount('visitors')->orderByDesc('visitors_count')->paginate(10);
        return view('backend.index',['posts' => $posts,'total_categories' => $total_categories,'post_count' => $post_count,'total_comments' => $total_comments]);
    }

    public function profile()
    {
        return view('backend.settings.profile');
    }

    public function updateProfile(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'password' => 'nullable|confirmed|min:6'
        ]);

        $user = User::findOrFail(auth()->user()->id);
        $user->name = $request->name;
        $user->bio = $request->bio;
        if($request->hasFile('profile_pic')){
            $user->image = $request->profile_pic->store('uploads/users');
        }
        $user->password = Hash::make($request->password);
        $social_links = json_encode([
                            'fb_link' => $request->fb_link,
                            'twitter_link' => $request->twitter_link,
                            'instagram_link' => $request->instagram_link,
                            'youtube_link' => $request->youtube_link,
                        ]);
        $user->social_links = $social_links;
        $user->save();

        return back()->with('success','Profile updated successfully!');
    }
}
