<?php

namespace App\Http\Controllers\Backend;

use App\Models\Post;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Artisan;


class PostController extends Controller
{
    
    public function index()
    {
        $posts = Post::withCount('visitors')->latest()->paginate(10);
        $categories = Category::all();
        return view('backend.posts.index',['posts' => $posts,'categories' => $categories]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'description' => 'required',
            'image' => 'required',
            'tags' => 'required',
        ]);

        try {
            DB::beginTransaction();
            $post = new Post();
            $post->title = $request->title;
            $post->description = $request->description;
            $post->tags = $request->tags;
            $post->category_id = $request->category_id;
            $post->user_id = auth()->user()->id;
            $post->image = $request->image->store('uploads/posts');
            if(Post::where('slug',slug($request->title))->exists()){
                $post->slug = slug($request->title).'-'.rand(100,900);
            }else{
                $post->slug = slug($request->title);
            }

            if(!is_null($request->meta_title)){
                $post->meta_title = $request->meta_title;
            }else{
                $post->meta_title = $request->title;
            }

            if(!is_null($request->meta_description)){
                $post->meta_description = $request->meta_description;
            }else{
                $post->meta_description = strip_tags($request->description);
            }

            if(!is_null($request->meta_image)){
                $post->meta_image = $request->meta_image;
            }else{
                $post->meta_image = $post->image;
            }

            $post->save();

            Artisan::call('cache:clear');
            DB::commit();

            return back()->with('success','Post added successfully!');

        } catch (\Throwable $th) {
            DB::rollBack();
            return back()->with('error','Sorry, Something went wrong!');
        }
    }

    public function imageStore(Request $request)
    {
        $request->validate([
            'upload' => 'image',
        ]);
        if ($request->hasFile('upload')) {
            $image = $request->upload->store('uploads/editor');
            $CKEditorFuncNum = $request->input('CKEditorFuncNum');
            $url = assetFile($image);
            $msg = 'Image successfully uploaded';
            $response = "<script>window.parent.CKEDITOR.tools.callFunction($CKEditorFuncNum, '$url', '$msg')</script>";
            @header('Content-type: text/html; charset=utf-8');
            return $response;
        }
        abort(404);

    }

    public function edit($id)
    {
        $post = Post::findOrFail(decrypt($id));
        $categories = Category::all();

        return view('backend.posts.edit',['post' => $post,'categories' => $categories]);
    }

    public function update(Request $request,$id)
    {
        $request->validate([
            'title' => 'required',
            'description' => 'required',
            'image' => 'required',
            'tags' => 'required',
        ]);

        try {
            DB::beginTransaction();
            $post = Post::findOrFail(decrypt($id));
            $post->title = $request->title;
            $post->description = $request->description;
            $post->tags = $request->tags;
            $post->category_id = $request->category_id;
            $post->user_id = auth()->user()->id;
            if($request->hasFile('image')){
                $post->image = $request->image->store('uploads/posts');
            }
            if(Post::whereNotIn('id',[decrypt($id)])->where('slug',slug($request->title))->exists()){
                $post->slug = slug($request->title).'-'.rand(100,900);
            }else{
                $post->slug = slug($request->title);
            }

            if(!is_null($request->meta_title)){
                $post->meta_title = $request->meta_title;
            }else{
                $post->meta_title = $request->title;
            }

            if(!is_null($request->meta_description)){
                $post->meta_description = $request->meta_description;
            }else{
                $post->meta_description = $request->description;
            }

            if(!is_null($request->meta_image)){
                if($request->hasFile('meta_image')){
                    $post->meta_image = $request->meta_image;
                }
            }else{
                if($request->hasFile('image')){
                    $post->meta_image = $post->image;
                }
            }

            $post->save();
            
            Artisan::call('cache:clear');

            DB::commit();

            return back()->with('success','Post updated successfully!');

        } catch (\Throwable $th) {
            DB::rollBack();
            return back()->with('error','Sorry, Something went wrong!');
        }
    }

    public function delete($id)
    {
        try {
            DB::beginTransaction();
            $post = Post::findOrFail(decrypt($id));
            $post->delete();
            DB::commit();
            return back()->with('success','Post Deleted Successfully!');

        } catch (\Throwable $th) {
            DB::rollBack();
            return back()->with('error','Sorry, Something went wrong!');
        }
    }
}
