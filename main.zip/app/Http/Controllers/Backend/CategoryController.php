<?php

namespace App\Http\Controllers\Backend;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;


class CategoryController extends Controller
{

    public function index()
    {
        $categories = Category::latest()->paginate(10);
        return view('backend.category.index',['categories' => $categories]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required'
        ]);

        try {
            DB::beginTransaction();
            $category = new Category();
            $category->name = $request->name;
            if(Category::where('slug',slug($request->name))->exists()){
                $category->slug = slug($request->name).'-'.rand(100,900);
            }else{
                $category->slug = slug($request->name);
            }
            $category->is_featured = $request->is_featured;
            $category->save();
            DB::commit();
            return back()->with('success','Category Added Successfully!');
        } catch (\Throwable $th) {
            DB::rollBack();
            return back()->with('error','Sorry, Something went wrong!');
        }
    }

    public function edit($id)
    {
        $category = Category::findOrFail(decrypt($id));
        return view('backend.category.edit',['category' => $category])->render();
    }

    public function update(Request $request,$id)
    {
        $request->validate([
            'name' => 'required'
        ]);

        
        try {
            DB::beginTransaction();
            $category = Category::findOrFail(decrypt($id));
            $category->name = $request->name;
            if(Category::where('slug',slug($request->name))->exists()){
                $category->slug = slug($request->name).'-'.rand(100,900);
            }else{
                $category->slug = slug($request->name);
            }
            $category->is_featured = $request->is_featured;
            $category->update();
            DB::commit();
            return back()->with('success','Category Updated Successfully!');
        } catch (\Throwable $th) {
            DB::rollBack();
            return back()->with('error','Sorry, Something went wrong!');
        }
    }

    public function delete($id)
    {
        try {
            $category = Category::findOrFail(decrypt($id));
            $category->delete();
            return back()->with('success','Category Deleted Successfully!');

        } catch (\Throwable $th) {
            return back()->with('error','Sorry, Something went wrong!');
        }
    }
}
