<?php

namespace App\Http\Controllers\Backend;

use App\Models\Menu;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class MenuController extends Controller
{
    public function store(Request $request)
    {
        $menu = new Menu();
        $menu->name = $request->name;
        $menu->link = $request->link;
        $menu->save();

        return back()->with('success','Menu added successfully!');
    }

    public function update(Request $request,$id)
    {
        $menu = Menu::findOrFail(decrypt($id));
        $menu->name = $request->name;
        $menu->link = $request->link;
        $menu->save();

        return back()->with('success','Menu updated successfully!');
    }

    public function delete($id)
    {
        Menu::destroy(decrypt($id));

        return back()->with('success','Menu deleted successfully!');
    }
}
