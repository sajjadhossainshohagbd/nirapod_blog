<?php

namespace App\Http\Controllers\Frontend;

use App\Models\Comment;
use App\Models\CommentReply;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;


class CommentController extends Controller
{
    public function store(Request $request)
    {
        $comment = new Comment();
        $comment->user_id = auth()->user()->id;
        $comment->post_id = $request->post_id;
        $comment->comment = $request->comment;
        $comment->save();

        return back()->with('success','Comment added successfully!');
    }

    public function replyStore(Request $request)
    {
        $reply = new CommentReply();
        $reply->user_id = auth()->user()->id;
        $reply->comment_id = $request->comment_id;
        $reply->reply = $request->reply;
        $reply->save();

        return back()->with('success','Comment reply added successfully!');
    }
}
