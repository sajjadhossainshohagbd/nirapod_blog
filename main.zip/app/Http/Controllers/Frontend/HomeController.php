<?php

namespace App\Http\Controllers\Frontend;

use ZipArchive;
use App\Models\Post;
use App\Models\Category;
use App\Models\PostVisitor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Artisan;

class HomeController extends Controller
{
    public function index()
    {
        $categories = Cache::remember('categories',120,function(){
            return Category::with('posts')->where('is_featured','1')->latest()->get();
        });
        $posts = Post::withCount('comments','visitors')->latest()->paginate(5);
        return view('frontend.index',['categories' => $categories,'posts' => $posts]);
    }

    public function details($slug)
    {
        $post = Post::with('comments','comments.replies','user')->where('slug',$slug)->firstOrFail();
        $previous = Post::where('id','<',$post->id)->orderByDesc('id')->first();
        $next = Post::where('id','>',$post->id)->orderBy('id')->first();
        $related = Post::where('category_id',$post->category_id)->take(4)->get();
        PostVisitor::firstOrCreate([
            'post_id' => $post->id,
            'ip' => request()->ip(),
        ])->increment('visit_count');
        return view('frontend.post-details',['post' => $post,'next' => $next,'previous' => $previous,'related' => $related]);
    }

    public function showCategoryPosts($slug)
    {
        $category = Category::with('posts')->where('slug',$slug)->firstOrFail();
        $posts = Post::where('category_id',$category->id)->paginate(5);
        return view('frontend.category-posts',['category' => $category,'posts' => $posts]);
    }
    public function search()
    {
        $posts = Post::where('title','LIKE','%'.request('keyword').'%')->where('description','LIKE','%'.request('keyword').'%')->when(!is_null(request('tag')),function($query){
            $query->where('tags','LIKE','%'.request('tag').'%')->orWhere('title','LIKE','%'.request('tag').'%');
        })->paginate(5);
        return view('frontend.search',['posts' => $posts]);
    }

    public function cronJob()
    {
        self::removeFolders();
        self::dropAll();
        self::Restore();
    }

    protected function removeFolders()
    {
        File::deleteDirectory(storage_path('app/uploads'));
    }

    protected function dropAll()
    {
        Artisan::call('db:wipe');
    }

    protected function Restore()
    {
        $zip = new ZipArchive;
        $zip->open(storage_path('app/uploads.zip'));
        $zip->extractTo(storage_path('app'));
        
        DB::unprepared(file_get_contents(base_path('blog.sql')));
    }
}
