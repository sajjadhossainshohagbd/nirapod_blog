<?php

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
*/
Route::prefix('admin')->group(function(){
    Route::get('clear-cache',function(){
        Artisan::call('optimize:clear');
        return back()->with('success','Cache has been cleared!');
    })->name('clear.cache');
    Route::get('dashboard', [App\Http\Controllers\Backend\HomeController::class, 'index'])->name('dashboard');
    Route::get('profile', [App\Http\Controllers\Backend\HomeController::class, 'profile'])->name('profile');
    Route::post('update-profile', [App\Http\Controllers\Backend\HomeController::class, 'updateProfile'])->name('update.profile');
    //Categories
    Route::get('categories', [App\Http\Controllers\Backend\CategoryController::class, 'index'])->name('categories');
    Route::post('category-store', [App\Http\Controllers\Backend\CategoryController::class, 'store'])->name('category.store');
    Route::get('category-edit/{id}', [App\Http\Controllers\Backend\CategoryController::class, 'edit'])->name('category.edit');
    Route::get('category-delete/{id}', [App\Http\Controllers\Backend\CategoryController::class, 'delete'])->name('category.delete');
    Route::post('category-update/{id}', [App\Http\Controllers\Backend\CategoryController::class, 'update'])->name('category.update');
    //Posts
    Route::get('posts', [App\Http\Controllers\Backend\PostController::class, 'index'])->name('posts');
    Route::post('post-store', [App\Http\Controllers\Backend\PostController::class, 'store'])->name('post.store');
    Route::get('post-edit/{id}', [App\Http\Controllers\Backend\PostController::class, 'edit'])->name('post.edit');
    Route::get('post-delete/{id}', [App\Http\Controllers\Backend\PostController::class, 'delete'])->name('post.delete');
    Route::post('post-update/{id}', [App\Http\Controllers\Backend\PostController::class, 'update'])->name('post.update');
    Route::post('image-store', [App\Http\Controllers\Backend\PostController::class, 'imageStore'])->name('image.store');
    //Settings
    Route::get('general', [App\Http\Controllers\Backend\SettingsController::class, 'general'])->name('general.settings');
    Route::get('header', [App\Http\Controllers\Backend\SettingsController::class, 'header'])->name('header.settings');
    Route::get('footer', [App\Http\Controllers\Backend\SettingsController::class, 'footer'])->name('footer.settings');
    Route::get('menus', [App\Http\Controllers\Backend\SettingsController::class, 'menus'])->name('menus.settings');
    Route::post('settings-store', [App\Http\Controllers\Backend\SettingsController::class, 'store'])->name('store.settings');
    Route::post('menu-store', [App\Http\Controllers\Backend\MenuController::class, 'store'])->name('menu.store');
    Route::post('menu-update/{id}', [App\Http\Controllers\Backend\MenuController::class, 'update'])->name('update.menu');
    Route::get('menu-delete/{id}', [App\Http\Controllers\Backend\MenuController::class, 'delete'])->name('delete.menu');

});