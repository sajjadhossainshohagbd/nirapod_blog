<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
*/

Route::get('/',[App\Http\Controllers\Frontend\HomeController::class,'index'])->name('home');
Route::get('cron-job',[App\Http\Controllers\Frontend\HomeController::class,'cronJob'])->name('cronJob');
Route::get('details/{slug}',[App\Http\Controllers\Frontend\HomeController::class,'details'])->name('post.details');
Route::get('category/{slug}',[App\Http\Controllers\Frontend\HomeController::class,'showCategoryPosts'])->name('category.posts');
Route::get('search',[App\Http\Controllers\Frontend\HomeController::class,'search'])->name('search');
Route::post('comment-store',[App\Http\Controllers\Frontend\CommentController::class,'store'])->name('comment.store');
Route::post('comment-reply-store',[App\Http\Controllers\Frontend\CommentController::class,'replyStore'])->name('comment.reply.store');










Auth::routes();

